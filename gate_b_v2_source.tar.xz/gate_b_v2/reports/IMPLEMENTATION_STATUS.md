# Gate B v2 code implementation status

Updated: 2026-11-16 after B2 v1.1 implementation and PREFLIGHT.

## Authoring baseline (unchanged facts)

The archive's unit tests and implementation were authored without importing
Diffusion Policy, robomimic, robosuite, MuJoCo, the checkpoint or the dataset.
That authoring baseline was 8 tests; it is superseded by the workstation run
below.

## Workstation integration performed

- Checkpoint-native loading through the upstream DP workspace payload; EMA
  selected because `training.use_ema=true`.
- The checkpoint is the **absolute-action** variant: action shape 10,
  `abs_action=true`, `rotation_6d`, `control_delta=false`. Implemented the
  official 10→7 conversion and DP's 6-D rotation convention.
- Checkpoint H=16, To=2, `n_action_steps=8`; only 15 future actions exist, so
  h=16 remains invalid and B1 is blocked.
- The normalizer is stored in the model/EMA state dict (36 keys), not in the
  pickled payload; loading is verified.
- Two 84×84 RGB cameras, proprio dims 3/4/2 and 7-D OSC actions are verified
  on the live simulator.
- Live collision-geometry inference: SquareNut aperture half-extents
  0.02275 m, peg half-extent 0.016 m.
- Final-state robomimic success predicate; sticky `success_seen` is diagnostic.
- OSMesa rendering matches official stored frames (corr 0.998, mean diff
  ~1.5/255); policy queries on official observations match the next demo pose
  within 0.8–2.5 cm and reproduce the gripper sign.
- Closed-loop from an official demo start state succeeds.

## Verification

- `pytest -q`: **25 passed**.
- `compileall`: clean.
- `bash -n` on all launchers: clean.

## Current status (2026-11-11)

1. **CUDA resolved by the authorized reboot**: kernel module and userspace are
   both 580.178.04; the RTX 3090 passes real matmul and cuDNN checks. A
   workspace-local `.cuda_compat/libcuda.so` symlink is needed because cuDNN
   dlopens the unversioned name; no system file was changed.
2. **Formal B0 completed**: 84/100 (0.84) on seeds 100000–100099, h=8, 500
   steps, device cuda:0. Wilson 95 % CI 0.7558–0.8990. No episode was skipped
   or replaced; 16 real failures are retained. See `reports/B0_REPORT.md`.
3. **B1 completed**: Pilot 100/100 episodes (82 success) and Full 500/500
   episodes (399 success) ran under the locked environment. Full results:
   h=1 0.66, h=2 0.72, h=4 0.81, h=8 0.87, h=15 0.93; Cochran Q=34.2,
   df=4, p=6.78e-7. h=1 and h=2 are significantly below h=8 after Holm
   correction; h=15 is non-inferior and substantially cheaper. B1 does not
   prove CAC. See `reports/B1_FULL_REPORT.md`.
4. **B2 v1.1 implementation (2026-11-16)**: the frozen B2 protocol was
   implemented on branch `codex/b2-protocol-20261116` at protocol commit
   `4e7fcd5f856a8fae4d0d7844569c4c2c17a1c957`. Added independent B2 state
   harvesting, live collision-geometry audit, geometry-derived stage gate,
   strengthened snapshot/restore validation, h=15 continuation, deterministic
   branch order with common policy-noise seeds, strict 30×5×3 completeness
   checks, the state-level primary contrast with 5,000 state-cluster bootstrap,
   and locked B2 CLI/config. The live geometry audit PASSed and the reserved
   seed-299999 snapshot/replay PREFLIGHT PASSed. No formal discovery or
   confirmation state was collected and no B2 branch episode was run. Full
   evidence is in `reports/B2_IMPLEMENTATION_ACCEPTANCE_REPORT.md`.

## Interpretation limits

The checkpoint's 1.000 was measured on its own `test_start_seed=4,500,000`,
not the Gate B seeds 100000–100099; B0 is a new measurement on the protocol
seeds under the checkpoint-native 10-D absolute-action semantics. No Gate C
decision is made.

See `reports/CODE_REVIEW.md`, `reports/B0_STATUS.md` and
`reports/WORKSTATION_EXECUTION_LOG.md`.
